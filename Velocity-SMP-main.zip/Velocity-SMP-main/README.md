![VelocitySMP-MC-Title](https://github.com/user-attachments/assets/e1b4565c-7639-4f09-a3e8-9b70b6f90ead)

# Velocity SMP Official Website

### Welcome to the Official Website of Velocity SMP

A Minecraft server where creativity knows no bounds and adventures await around every corner! Immerse yourself in a world where imagination takes center stage and the possibilities are endless.

Embark on epic quests, build magnificent structures, or simply let your creativity run wild as you explore the vast landscapes of our server. Whether you're a seasoned builder, a daring adventurer, or just looking to make new friends, there's something for everyone on Velocity SMP.


## Features of Website
- Server address copy button
- Modern design
- Discord server embed
- Team member cards
- Bedrock and Java IP cards
- Navbar
- Mobile support
- Simple Configuration
- Hover animations

## How to Join
Go to the Official website and copy the server IP and paste the server IP in the join server tab in minecraft.

## Website Version


## Screenshots
(W.I.P.) Screenshots will be coming soon!
![image](https://github.com/user-attachments/assets/3062e480-22cd-4527-ad9a-7f15e9488b51)
![image](https://github.com/user-attachments/assets/ec0a2e40-4e34-4ad5-b8a5-d16792da2d1f)
![image](https://github.com/user-attachments/assets/a24719a6-8db6-40bb-9438-c402e82d01a4)
![image](https://github.com/user-attachments/assets/6cec1165-980b-4137-b2dc-f4ef61bf187e)
![image](https://github.com/user-attachments/assets/a0c945a1-401c-48be-b645-240fe08675fb)

## Authors
- [Im_NotCool](https://github.com/fir15playz)

## Credits
- [@FQQD](https://github.com/FQQD) - Top Navbar
- [HerrFisch](https://github.com/HerrFisch) - Website Inspration

## Lastly...
If you have any further question or want to help and contribute, the best ways to do this are
- Report an [Issue](https://github.com/fir15playz/Velocity-SMP/issues) if you find any problems on the website.
- Join [my Discord](https://discord.gg/Nxh2zXxYJ7) and ask for help

Here's a cookie for reading this far: 🍪
